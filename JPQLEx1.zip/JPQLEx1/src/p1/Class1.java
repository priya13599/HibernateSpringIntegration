package p1;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Class1 
{
	@Id
int a;
String b;
public int getA() 
{
	return a;
}
public void setA(int a) {
	this.a = a;
}
public String getB() {
	return b;
}
public void setB(String b) {
	this.b = b;
}
@Override
public String toString() {
	return "Class1 [a=" + a + ", b=" + b + "]";
}

}
