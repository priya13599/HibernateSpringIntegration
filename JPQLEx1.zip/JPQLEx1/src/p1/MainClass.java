package p1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class MainClass {

	public static void main(String[] args) 
	{

	EntityManagerFactory fact=Persistence.createEntityManagerFactory("std1");
	EntityManager em=fact.createEntityManager();
	em.getTransaction().begin();

	//EntityTransaction t=em.getTransaction();
	/*Class1 c=new Class1();
	c.setA(206);
	c.setB("bbbb");
	em.persist(c);*/

	Query query1=em.createQuery("from Class1");
	System.out.println(query1.getResultList());
	
	
	em.getTransaction().commit();
	}

}
