package com.nucleus.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

@Entity
@Table(name="Subject0")
@NamedQueries(value = { @NamedQuery(name = "getAllSubjects", query = "from Subject") })
public class Subject {
	/*@ManyToOne
Student student;
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}*/
	@Id
private int subCode;
private String subName;

@Override
public String toString() {
	return "Subject [subCode=" + subCode + ", subName=" + subName + "]";
}
public int getSubCode() {
	return subCode;
}
public void setSubCode(int subCode) {
	this.subCode = subCode;
}
public String getSubName() {
	return subName;
}
public void setSubName(String subName) {
	this.subName = subName;
}

}
