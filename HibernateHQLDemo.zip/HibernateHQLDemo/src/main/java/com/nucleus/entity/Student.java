package com.nucleus.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;



@Entity
@Table(name="Student9090")
@NamedQuery(name = "getAllData", query = "from Student")
public class Student {
	
	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", studentname=" + studentname + ", studentmarks=" + studentmarks
				+ ", studentcourse=" + studentcourse + "]";
	}
	@Id
	private String studentid;
	private String studentname;
	private String studentmarks;
	private String studentcourse;
	public String getStudentid() {
		return studentid;
	}
	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getStudentmarks() {
		return studentmarks;
	}
	public void setStudentmarks(String studentmarks) {
		this.studentmarks = studentmarks;
	}
	public String getStudentcourse() {
		return studentcourse;
	}
	public void setStudentcourse(String studentcourse) {
		this.studentcourse = studentcourse;
	}
	
	
	
	

}
