package com.nucleus.execution;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nucleus.entity.Student;

public class Main {
	
	public static void main(String[] args) {
		Configuration configuration  = new Configuration();
		configuration.configure();
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		
		
		/*Student student = new Student();
		student.setStudentid("103");
		student.setStudentname("Krishna");
		student.setStudentmarks("95");
		student.setStudentcourse("B.Tech");
		session.persist(student);
		*/
		
		// ToGet All Data 
		/*Query query = session.createQuery("from Student");
		System.out.println(query.list());
		*/
		
		
		//Positional Parameter
		/*Query query = session.createQuery("from Student where studentname=:studentname");
		query.setParameter("studentname","Priya");
		System.out.println(query.list());*/
		
		
		//To Fetch Particular Row Data
		/*Query query = session.createQuery("select studentname from Student");
		List<String> list = query.list();
		for(String list1:list)
		{
			System.out.println(list);
		}*/
		
		
		/*Query query = session.createQuery("select studentname,studentid from Student");
		List<Object> list = query.list();
		for(Object list1:list)
		{
			System.out.println(list1.toString());
		}*/
		
		
		
		//Named Query
		
		Query query = session.getNamedQuery("getAllData");
		System.out.println(query.list());
		
		
		
		transaction.commit();
		session.close();
		factory.close();
		
	}

}
