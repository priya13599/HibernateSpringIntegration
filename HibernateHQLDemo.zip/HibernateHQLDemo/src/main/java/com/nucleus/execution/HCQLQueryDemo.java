package com.nucleus.execution;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.nucleus.entity.Student;

public class HCQLQueryDemo {
	
	
	public static void main(String[] args) {
		Configuration configuration  = new Configuration();
		configuration.configure();
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Student.class);
		System.out.println(criteria.list());
		
		criteria.addOrder(Order.asc("studentname"));
		System.out.println(criteria.list());
		
		/*criteria.add(Restrictions.isEmpty("studentname"));
		System.out.println(criteria.list());*/
		
		criteria.add(Restrictions.gt("studentmarks", "92"));
		System.out.println(criteria.list());
		
		criteria.add(Restrictions.like("studentname", "Pr%"));
		System.out.println(criteria.list());
		
		
		transaction.commit();
		session.close();
		factory.close();
	}

}
