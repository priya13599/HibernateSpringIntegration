package com.nucleus.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import org.hibernate.validator.constraints.Length;
@Entity
@Table(name="cust000")
public class Customer {
//@Min(value=100, message="Minimum value for customerid is 100")
	@Min(value=100)
	@Id
private int customerid;

@Length(min=3, max=10)
//@Email
private String custname;
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int customerid) {
	this.customerid = customerid;
}
public String getCustname() {
	return custname;
}
public void setCustname(String custname) {
	this.custname = custname;
}

}
